<?php

require_once('./autoloader.php');


echo Person::read();


 ?>