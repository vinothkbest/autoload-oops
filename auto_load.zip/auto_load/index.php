 <!DOCTYPE html>
 <html>
 <head>
 	<title>Register Form</title>
 </head>
 <link rel="stylesheet" href="./assets/lib/bootstrap.min.css">
 <link rel="stylesheet" href="./assets/style.css">
 <script type="text/javascript" src="./assets/lib/jquery.min.js"></script>
 <script type="text/javascript" src="./assets/lib/bootstrap.min.js"></script>
 <script type="text/javascript" src="./assets/read.js"></script>
 <script type="text/javascript" src="./assets/write.js"></script>
 <body>
 <div class="container forms">
 	<form id="formcreate" action="" method="post" enctype="multipart/form-data">
 		<div class="panel">
			<input type="text" name="name" id="name" placeholder="Name" autocomplete="off" required>
			<input type="text" name="dept" id="dept" placeholder="Department" autocomplete="off" required>
			<input type="text" name="email" id="email" placeholder="Email" autocomplete="off" required>
			<input type="password" name="password" id="pwd" placeholder="Password" autocomplete="off" required>
 		</div>
 		<div class="save">
 			<input type="submit" name="submit" value="Add Record">
 		</div>
 	</form>
 	<div class="crud" style="margin-top: 25px;">
 		
 	</div>
 	<form id="formread" action="" method="post" enctype="multipart/form-data" style="margin-top: 25px;">
 			<input type="text" name="search" class="search" placeholder="Search Record" autocomplete="off">
 	</form>

 	<div class="response" style="margin-top: 50px;">
	
	</div>
 </div>
 </body>
 </html>
 
