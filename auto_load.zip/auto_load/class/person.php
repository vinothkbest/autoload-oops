<?php

class Person{

	public static function create($name, $dept, $email, $password){

		require_once './db.php';
	
		$password = password_hash($password, PASSWORD_DEFAULT);

		$put = "CALL PutPersonDetails ('$name', '$dept', '$email', '$password')";
		
		return (mysqli_query($conn, $put)) ? 'data stored!' : 'data not stored'; 

	}

	public static function read(){
		
		require_once './db.php';

		$rows = mysqli_query($conn, "SELECT * FROM Person");

		$record = array();

		while ($data = mysqli_fetch_assoc($rows)) :

			array_push($record, array($data['Name'], $data['Department'], $data['Email']));

		endwhile;

		return json_encode($record);
	}

}

 ?>