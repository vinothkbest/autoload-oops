<?php

class fruits{

	public $fruit;

	public $color;

	public function __construct($fruit, $color){

			$this->fruit = $fruit;
			$this->color = $color;
	}

	public function getperson(){

		return $this->fruit . ' ' . $this->color;

	}
}

 ?>