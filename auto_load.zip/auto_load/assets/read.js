$.ajax({
url : './read.php',
cache: false,

success : function(response){
	console.log(response.trim());
	var people = $.parseJSON(response);
	$('.response').append("<table/>");
	var th, tr;
	tr = $('<tr/>');
	tr.append("<th>Name</th>");
	tr.append("<th>Department</th>");
	tr.append("<th>Email</th>");
	$('table').append(tr);
		for (var i = 0; i < people.length; i++) {
			tr = $('<tr/>');
			tr.append("<td>" + people[i][0] + "</td>");
			tr.append("<td>" + people[i][1] + "</td>");
			tr.append("<td>" + people[i][2] + "</td>");
			$('table').append(tr);
		}
	},
});
