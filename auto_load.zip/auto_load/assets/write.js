$(document).ready(function(){

//Write File
	$('#formcreate').on('submit', function(){
		var data = $(this).serialize();

		$.ajax({
		url : './create.php',
		type : 'post',
		data : data,
		cache: false,

		success : function(response){


				location.href = "./index.php";

			},
		});		
	return false;
	});
	
});

