<?php

require_once('./autoloader.php');


	if(isset($_POST['name']) && isset($_POST['dept']) && isset($_POST['email'])) :

		echo Person::create($_POST['name'], $_POST['dept'], $_POST['email'], $_POST['password']);
	
	else : echo 'Not recorded!';

	endif;	


 ?>