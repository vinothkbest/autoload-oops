<?php

$conn = mysqli_connect('localhost', 'root', '', 'training');

/*
use training;

DROP TABLE  TodoList;        

DROP TABLE person;

CREATE TABLE Person (PID INT NOT NULL AUTO_INCREMENT, 
                     Name varchar(255) NOT NULL, Department varchar(255) NOT NULL,
                     Email varchar(255) NOT NULL UNIQUE KEY,
                     Password varchar(255) NOT NULL, PRIMARY KEY(PID));
                     
                    
CREATE TABLE TodoList (PID INT NOT NULL, 
                     TaskID INT NOT NULL, Project varchar(255) NOT NULL, Status varchar(255) NOT NULL,
                    PRIMARY KEY(PID, TaskID), FOREIGN KEY(PID) REFERENCES Person(PID)); 

 DELIMITER //


CREATE PROCEDURE PutPersonDetails(IN pname varchar(255), IN pdept varchar(255),
                                  IN pemail varchar(255), IN ppaswd varchar(255))
 
BEGIN 

INSERT INTO `person`(`Name`, `Department`, `Email`, `Password`) 
				VALUES (pname, pdept, pemail, ppaswd);
END //

DELIMITER ;

ALTER TABLE person AUTO_INCREMENT = 100

DELIMITER //


CREATE PROCEDURE ReadPersonDetails(IN input varchar(255))
 
BEGIN 

DECLARE searchtext varchar(255);

SET searchtext = input;

SELECT * FROM person where Name LIKE  CONCAT('%', searchtext, '%')
							OR Email LIKE  CONCAT('%', searchtext , '%') 
                            OR Department LIKE  CONCAT('%', searchtext, '%');
						
END //

DELIMITER ;
*/



 ?>