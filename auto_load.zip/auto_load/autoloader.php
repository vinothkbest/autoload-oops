<?php

spl_autoload_register('autoloader');

function autoloader($class_name){

		$path = './class/' . $class_name . '.php';

		require_once $path;
}

?>